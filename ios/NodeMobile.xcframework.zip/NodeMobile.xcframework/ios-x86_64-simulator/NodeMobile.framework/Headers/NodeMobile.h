
#ifdef __cplusplus
extern "C" {
#endif
    
int node_start(int argc, char *argv[]);

#ifdef __cplusplus
}
#endif
